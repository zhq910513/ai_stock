# 潜伏抬头模型归类总结

## 1. 模型定位

`ambush-watchlist-service` 是潜伏抬头模型 `ambush_watchlist` 的独立 owner service。

它是一个深圳 A 股低位弱转强结构扫描模型，目标是识别：

```text
尚未明显走热
但已经从成熟低谷中抬头
具备后续验证价值的标的
```

模型依据包括：

- 低谷图库
- 多通道 OHLCV 数值序列
- hard negative
- 低谷成熟度
- 有效抬头新鲜度
- 资金确认
- 板块确认
- 市场确认
- 可交易性确认

模型不依赖热点模型历史，不使用同花顺教师概率作为核心先验。

它不直接采集 provider，不直接读取 `raw_*`，不反写前端、Jarvis 或学习权重。

---

## 2. 当前版本

| 项目 | 当前值 |
|---|---|
| 模型名 | `ambush_watchlist` |
| 兼容 / 基础模型版本 | `ambush_watchlist_effective_turn_v1_1` |
| 图库版本 | `ambush_valley_pattern_library_v1_0` |
| 公式治理版本 | `ambush_formula_governance_v1_0` |
| Phase2 | `ambush_watchlist_phase2_valley_turn_v1_0_rc` |
| Phase3 | `ambush_watchlist_phase3_release_signal_v1_0_rc` |
| Phase4 | `ambush_watchlist_phase4_closed_loop_v1_0_rc` |
| 锁定候选 | `ambush_watchlist_service_v1.0_rc_backend_closure_candidate` |

---

## 3. 服务边界

### 3.1 允许做的事

- 接收 research-service 或编排层组装好的真实 payload。
- 执行 source capability audit。
- 生成低谷 shape signature。
- 执行图库原型匹配。
- 执行三路召回。
- 构建 valley watch pool。
- 识别 effective turn anchor。
- 执行 pool transition audit。
- 执行 Phase3 deep confirmation。
- 执行 Phase3 release gate。
- 生成买点参考。
- 生成 Phase4 observation。
- 生成 outcome。
- 生成失败归因。
- 输出 finalization lock candidate 合同。
- 返回 Jarvis 只读解释 payload。

### 3.2 禁止做的事

- 不直接采集 BaoStock、AKShare、Tencent、Tushare、EastMoney、Baidu、CNINFO 等 provider。
- 不直接读取 `raw_*`。
- 不依赖热点模型历史。
- 不把同花顺付费概率作为核心先验。
- 不绕过 source preflight。
- 不用 0、空字符串、mock 或 GPT 推断补齐 source 缺口。
- 不反写前端、Jarvis、学习权重或其他模型事实。
- 不提供交易建议。

---

## 4. 核心状态流

```text
source_capability_audit
-> shape_signature / pattern_prototype_match
-> three_channel_recall
-> valley_watch_pool
-> effective_turn_anchor
-> pool_transition_audit
-> phase3 deep_confirmation
-> release_gate
-> signal_fact contract
-> buy_point reference
-> observation
-> outcome
-> failure_attribution / pattern feedback
-> finalization lock candidate
```

这条链路可以理解为：

```text
先确认数据能力
再识别低谷形态
再召回潜在候选
再判断是否成熟低谷
再判断是否有效抬头
再做资金/板块/市场/可交易性确认
最后进入发布、观察、结果和反馈闭环
```

---

## 5. 阶段拆分

### 5.1 Phase1：source capability 与图库

Phase1 负责两个基础能力：

#### source capability

判断当前 source 是否足够支持图形和结构计算。

关键要求：

- P0 日线 OHLCV 覆盖率 `>= 98%`。
- `available_at` 覆盖率 `>= 98%`。
- 正式图形 / 结构计算要求 adjusted OHLC。
- 缺 adjusted OHLC 时只能 research-only。

#### 图库与形态

包括：

- 低谷样本标注。
- shape signature。
- pattern prototype match。
- positive prototype。
- false bottom prototype。
- hard negative prototype。
- three-channel recall。

### 5.2 Phase2：谷底观察和有效抬头

Phase2 负责从图形召回对象中筛出真正值得观察的低位抬头候选。

核心对象：

- `valley_watch_pool`
- `effective_turn_anchor`
- `effective_turn_pool`
- `pool_transition_audit`

#### Phase2 窗口

默认窗口：

```text
60
```

兼容窗口：

```text
20 / 30 / 40 / 60 / 90 / 120
```

#### Phase2 基础阈值

| 指标 | 阈值 |
|---|---|
| 日线完整度 | `>= 0.95` |
| 20 日平均成交额 | `>= 20,000,000` |
| 官方范围 | 深圳 A 股 |
| `valley_maturity_score` | `>= 62` |
| `false_rebound_risk` | `<= 68` |

#### Phase2 阻断条件

| 条件 | 结果 |
|---|---|
| `hard_negative_similarity >= 75` 且 `shape_edge_score < 25` | 阻断 |
| `false_rebound_risk >= 75` | 阻断 |
| 不在深圳 A 股范围 | 阻断 |
| 可交易性不满足 | 阻断 |
| 从谷底已经跑太远 | 阻断 |

#### Phase2 池状态

- `data_blocked`
- `valley_invalidated`
- `research_only`
- `not_qualified`
- `valley_watch`

#### 有效抬头状态

- `rejected`
- `backup_only`
- `accepted`

### 5.3 Phase3：深度确认和 release gate

Phase3 负责判断候选是否可以进入 official release。

它在有效抬头基础上增加：

- L2 结构确认
- L3 资金 / 量能确认
- L4 板块 / 市场 / 可交易性确认

#### 证据层级

| 层级 | 含义 |
|---|---|
| L1 | 有效抬头 |
| L2 | 结构确认 |
| L3 | 资金 / 量能确认 |
| L4 | 板块 / 市场 / 可交易性确认 |

#### Phase3 official 阈值

| 指标 | 阈值 |
|---|---|
| `MIN_OFFICIAL_TRADABILITY_SCORE` | `60` |
| `MIN_OFFICIAL_DEEP_CONFIRMATION_SCORE` | `64` |
| `MAX_OFFICIAL_FALSE_REBOUND_RISK` | `72` |
| `MAX_OFFICIAL_RUNAWAY_RISK` | `62` |
| `MAX_OFFICIAL_HARD_NEGATIVE_SIMILARITY` | `65` |

#### 深度状态

- `blocked`
- `research_only`
- `not_ready`
- `deep_confirmed`

#### release 状态

| 状态 | 含义 |
|---|---|
| `passed` | 进入 `official_signal` |
| `blocked` | `not_released` |

### 5.4 Phase4：观察、outcome 和反馈

Phase4 负责 release 后的闭环：

- observation
- outcome
- failure attribution
- pattern feedback
- evolution sample
- formula version evaluation

Phase4 outcome 才允许使用 signal 后路径数据。

在线阶段只能使用：

```text
trading_day <= as_of_trading_day
```

不能在 Phase2 / Phase3 偷看未来路径。

---

## 6. 输入数据

核心请求对象包括：

### instrument

- `instrument_id`
- `symbol`
- `exchange`
- `asset_type`
- `board`
- `is_active`
- `is_suspended`
- `is_st`
- `is_delisting_risk`
- `listing_days`
- `price_limit_regime`

### bars

日线数组必须包含：

- `trading_day` / `trade_date`
- `open` / `open_price`
- `high` / `high_price`
- `low` / `low_price`
- `close` / `close_price`
- `volume`
- `amount`

正式评分优先使用 adjusted OHLC 字段。

### weekly_bars

提供周线上下文。

### prototypes

图库原型，包括：

- positive
- false bottom
- hard negative

### 时间字段

- `as_of_trading_day`
- `as_of_time`

### Phase3 context

- `moneyflow_context`
- `sector_context`
- `market_context`
- `tradability_context`
- `event_news_context`

其中 `event_news_context` 只能来自 source-data-service 构建后的：

```text
source.event_news_v1
```

Baidu Finance `finance_news_feed` 当前只是 research-only 主源，CNINFO 是备源登记。

### Phase4

- `signal_fact`
- `buy_point`
- 成熟窗口内 `bars`

---

## 7. source preflight

official release 前必须通过：

```text
POST /source/release/preflight
```

当 preflight 返回：

```text
can_release_official_signal=false
```

模型不得发布 official。

### 7.1 P0 hard gate

P0 包括：

- 日线 OHLCV
- adjusted OHLC
- `available_at`
- tradability
- source freshness
- lineage

P0 不满足时不得 official。

### 7.2 资金确认 source

`source.stock_moneyflow_daily_v1.main_net_inflow` 是 L3 / L4 资金确认使用的 P1 degraded 字段。

口径：

- 主源：EastMoney `moneyflow_stock_series`
- 备源：Tushare `moneyflow.net_mf_amount`
- canonical 映射：`main_net_inflow`

缺失时：

- 可作为 degraded 非阻断项保留。
- 不得伪装成完整资金证据。
- 不得用 AKShare schema-mismatch 字段补齐。
- 不得用 0、空字符串或推断值补齐。

### 7.3 事件新闻 source

`source.event_news_v1` 的 Baidu Finance 新闻源只作为：

- 事件解释上下文。
- 题材解释上下文。
- research-only 证据。

它不改变：

- P0 日线 OHLCV gate。
- adjusted OHLC gate。
- tradability gate。
- source preflight hard gate。

缺失时保留事件上下文缺口，不补事实。

---

## 8. 缺口码和阻断

### 8.1 P0 / 结构缺口

- `daily_bar_missing`
- `daily_bar_incomplete`
- `price_channel_invalid`
- `adjusted_ohlc_missing`
- `adjusted_ohlc_missing_research_only`
- `available_at_missing_or_incomplete`
- `weekly_context_missing`
- `pattern_match_missing`
- `not_shenzhen_a_share_scope`
- `not_a_share_scope`
- `special_treatment_stock`
- `suspended_stock`
- `delisting_risk_stock`
- `inactive_instrument`
- `daily_bar_history_insufficient`

### 8.2 Phase2 阻断

- `hard_negative_similarity_dominates`
- `false_rebound_risk_too_high`
- `instrument_scope_or_tradability_blocked`
- `valley_pool_state_not_eligible`
- `runaway_from_trough`

### 8.3 Phase3 阻断

- `effective_turn_anchor_not_accepted`
- `valley_watch_not_eligible`
- `deep_confirmation_not_passed`
- `effective_turn_not_accepted`
- `valley_watch_not_official`
- `source_gap_blocks_official_signal`
- `deep_confirmation_score_below_threshold`
- `false_rebound_risk_too_high`
- `tradability_score_too_low`
- `runaway_risk_too_high`
- `hard_negative_similarity_too_high`
- `moneyflow_context_missing`
- `sector_context_missing`
- `market_context_missing`

缺口必须保留，不得补 0 或空字符串。

---

## 9. API 入口

### 9.1 健康检查

```text
GET /health
GET /healthz
GET /readyz
```

### 9.2 source capability 和图库

```text
POST /ambush/source-capability-audit
POST /ambush/shape-signature
POST /ambush/pattern-prototype-match
POST /ambush/historical-valley-sample-label
POST /ambush/three-channel-recall
```

### 9.3 兼容 dragon / L1-L3

```text
POST /dragon/window-feature
POST /dragon/window-features
POST /ambush/valley-watch
POST /ambush/effective-turn-candidate
POST /ambush/pool-transition-audit
POST /dragon/l2-candidate
POST /dragon/deep-analysis
```

### 9.4 生产阶段

```text
POST /ambush/phase2/valley-watch-pool
POST /ambush/phase2/effective-turn-anchor
POST /ambush/phase2/pool-transition
POST /ambush/phase2/run
POST /ambush/phase3/deep-confirmation
POST /ambush/phase3/release-gate
POST /ambush/phase3/run
POST /ambush/phase4/observation
POST /ambush/phase4/outcome
POST /ambush/phase4/failure-attribution
POST /ambush/finalization/lock-candidate
```

说明：

```text
/ambush/phase2/run 和 /ambush/phase3/run 是 side-effect free 阶段管道验证
生产持久化仍由编排 / 仓储层完成
```

---

## 10. 统一响应

统一响应结构：

```json
{
  "model_name": "ambush_watchlist",
  "model_version": "string",
  "structured_output": {},
  "jarvis_payload": {},
  "contract_gaps": []
}
```

主要 `structured_output`：

- `recall`
- `valley_watch`
- `effective_turn_candidate`
- `effective_turn_anchor`
- `transition_audit`
- `analysis`
- `phase2`
- `deep_confirmation`
- `release_gate`
- `phase3`
- `observation`
- `outcome_label`
- `failure_attribution`
- `lock_candidate`

Jarvis payload 只读，不能给交易建议，不能修改模型状态、分数或标签。

---

## 11. 落库合同

当前服务本身不直接写生产数据库。

持久化由编排 / 仓储层执行。

目标 SQL 文件：

- `infra/sql/0008_decision_ambush_phase1_pattern_library.sql`
- `infra/sql/0009_decision_ambush_phase2_valley_turn.sql`
- `infra/sql/0010_decision_ambush_phase3_phase4_finalization.sql`
- `infra/sql/bootstrap_schema.sql`
- `packages/db-schema/alembic/versions/0001_current_baseline.py`

目标 `decision_ambush.*` 合同包括：

- `decision_ambush.valley_pattern_library_version_v1`
- `decision_ambush.valley_pattern_sample_v1`
- `decision_ambush.valley_shape_signature_v1`
- `decision_ambush.valley_pattern_prototype_v1`
- `decision_ambush.valley_pattern_match_result_v1`
- `decision_ambush.ambush_daily_window_feature_v1`
- `decision_ambush.valley_watch_pool_v1`
- `decision_ambush.effective_turn_anchor_v1`
- `decision_ambush.effective_turn_pool_v1`
- `decision_ambush.ambush_pool_transition_audit_v1`
- `decision_ambush.deep_confirmation_pool_v1`
- `decision_ambush.ambush_feature_matrix_v1`
- `decision_ambush.ambush_score_fact_v1`
- `decision_ambush.ambush_release_gate_audit_v1`
- `decision_ambush.ambush_signal_fact_v1`
- `decision_ambush.ambush_buy_point_v1`
- `decision_ambush.ambush_observation_snapshot_v1`
- `decision_ambush.ambush_latest_state_v1`
- `decision_ambush.ambush_outcome_label_v1`
- `decision_ambush.ambush_failure_attribution_v1`
- `decision_ambush.ambush_evolution_sample_v1`
- `decision_ambush.ambush_formula_version_evaluation_v1`

当前 `bootstrap_schema.sql` 也包含：

- `decision.ambush_*`
- `decision.dragon_*`

兼容事实表。

运行事实以当前容器和 `bootstrap_schema.sql` 为准。

如果 `decision_ambush.*` 合同表未在运行库出现，不能由 README 声称已经持久化。

---

## 12. 调度

### 12.1 scheduler 任务

| task_code | endpoint |
|---|---|
| `ambush.source_capability.audit` | `POST /ambush/source-capability-audit` |
| `ambush.pattern_library.mine` | `POST /ambush/historical-valley-sample-label` |
| `ambush.phase2.valley_turn.close` | `POST /ambush/phase2/run` |
| `ambush.phase3.release_gate.close` | `POST /ambush/phase3/run` |
| `ambush.buy_point.reference` | `POST /ambush/phase3/run` |
| `ambush.observe.outcome.evolution` | `POST /ambush/phase4/outcome` |

### 12.2 调度时间

| 阶段 | 时间 |
|---|---|
| source capability | 每周或新 provider 激活前 |
| 图库挖掘 | 每日 `18:10` 增量，月度全量重建 / 影子评估 |
| Phase2 | 收盘后 `15:20`，可选 `10:30` 研究扫描 |
| Phase3 release gate | `15:35` |
| 买点参考 | `15:35` 收盘参考，后续可接下一交易日开盘窗口 |
| observation / outcome / evolution | 每日 `15:55` 加 T+5 / T+10 / T+20 成熟检查 |

---

## 13. 下游消费边界

| 下游 | 边界 |
|---|---|
| scheduler | 触发 owner endpoint，不改模型事实 |
| source-data-service | 提供 source row、lineage、quality、preflight |
| research-service / 编排层 | 组装真实输入、处理行级异常、持久化模型事实 |
| research-data-mart | 只读消费或同步 |
| data-inspector | 巡检 source、模型 ready 和闭环缺口 |
| execution-timing | 后续买点 / 时序评估，只读消费 |
| gateway / frontend | 只读展示 |
| Jarvis | 只读解释和提醒 |

---

## 14. 异常兜底

owner API 内部无法评分时返回：

```text
422
```

批处理编排层必须把单条或单阶段异常转为行级研究事实。

### 14.1 warning

```text
ambush_watchlist:row_failed:{symbol}:{stage}:{error_code}
```

### 14.2 transition audit

```text
decision_result=data_blocked
trigger_event=model_service_exception
```

### 14.3 window feature

所有窗口写：

```text
pass_l1_gate=false
blocked_model_service_exception
```

### 14.4 L2

```text
l2_status=blocked
liquidity_check=blocked_model_service_exception
```

### 14.5 deep

```text
dragon_state=dragon_failed
dragon_head_score=null
evidence_gap_penalty=100
```

### 14.6 payload 必须保留

- `stage`
- `symbol`
- `instrument_id`
- `as_of_time`
- `error_code`
- `error_message`
- 输入引用

单条失败不得拖垮整批。

有任一 `row_failed` 时，run 应返回：

```text
partial
```

---

## 15. 验收

### 15.1 定向测试

```bash
python -m pytest -q services/models_services/ambush-watchlist-service/tests
python -m pytest -q tests/test_ambush_phase1_sql_contract.py tests/test_ambush_phase2_sql_contract.py tests/test_ambush_phase3_phase4_sql_contract.py
```

### 15.2 跨服务验收

```bash
python scripts/core_services_acceptance.py --require-postgres
python scripts/core_services_acceptance.py --require-postgres --source-quality-matrix
```

真实 provider probe 由 source-data-service 和验收脚本执行。

本服务不得绕开 source orchestration 直接探 provider。

---

## 16. 当前闭环结论

当前潜伏抬头 owner service 已实现：

- source capability。
- 图库。
- 多通道签名。
- 三路召回。
- 谷底观察。
- 有效抬头。
- Phase3 release。
- 买点参考。
- observation。
- outcome。
- 失败归因。
- 锁定候选合同。

2026-06-14 本地 Docker 闭环中：

```bash
scripts/core_services_acceptance.py --require-postgres --real-provider-probe --source-quality-matrix
```

返回 0。

`ambush.phase3.release_gate.close` 经 scheduler live dispatch 到本服务返回 200。

source release preflight 结果：

```text
can_release_official_signal=true
coverage_status=passed
freshness_status=passed
blocking_reasons=[]
```

Baidu `source.event_news_v1` 已通过 source-data-service 真实 raw/source/lineage 写入验证，但在本模型中仍只作为：

```text
event_news_context
research-only 题材 / 事件解释证据
```

不改变 P0 / P1 source gate。

当前最小闭环依赖：

- source-data-service
- scheduler-service
- 后续持久化编排

未阻断优化项见根目录：

```text
需优化点.MD
```

---

## 17. 一句话总结

潜伏抬头模型是一个不依赖热点历史、不使用同花顺教师概率的低位弱转强结构扫描模型：它先用 source capability 和低谷图库确认数据与形态，再通过 Phase2 识别成熟低谷和有效抬头，Phase3 结合结构、资金、板块、市场和可交易性执行 release gate，Phase4 负责观察、outcome、失败归因和图形反馈；所有 official 都必须先过 `/source/release/preflight`，缺 adjusted OHLC、available_at、资金或事件上下文时必须保留缺口，不得补 0、不 mock、不绕过 source-data-service。
