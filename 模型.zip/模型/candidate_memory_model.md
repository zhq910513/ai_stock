# 候选记忆模型归类总结

## 1. 模型定位

`candidate-memory-service` 是候选记忆模型 `candidate_memory` 的独立 owner service。

它研究的是：

```text
曾经进入热点候选链路的股票
在离开热点短窗口后
是否出现延迟兑现、二波、慢趋势或失效风险
```

模型不复用热点模型 signal，不把 `memory_entity` 当作推荐信号。

每次正式二次激活必须生成新的：

```text
memory_signal_id
```

不得复用：

- `memory_entity_id`
- 热点 signal
- 历史 signal

模型只输出：

- seed
- entity
- source feature snapshot
- feature readiness
- pre-signal
- activation
- release gate
- buy point
- observation
- outcome
- 上涨原因归因
- 失败归因
- TTL / 阈值校准
- matched-control uplift
- shadow evaluation

模型不直接采集 provider，不直接读取 `raw_*`，不反写前端、Jarvis 或学习权重。

---

## 2. 当前版本

| 项目 | 当前值 |
|---|---|
| 模型名 | `candidate_memory` |
| 模型版本 | `candidate_memory_v1` |
| Phase 5 闭环 schema | `candidate_memory_phase5_v1` |

---

## 3. 服务边界

### 3.1 允许做的事

- 从热点成熟样本或 source signal 生成 memory seed。
- 聚合 memory entity。
- 构建 source feature snapshot。
- 执行 feature readiness audit。
- 扫描 pre-signal window。
- 生成 pre-signal case。
- 评估 activation case。
- 执行 release gate。
- 生成新的 memory signal。
- 评估 buy point。
- 生成 observation 和 latest state 投影。
- 生成 mature outcome。
- 生成上涨原因归因。
- 生成失败归因。
- 生成 evolution sample。
- 执行 TTL / threshold calibration。
- 执行 matched-control uplift。
- 执行 model version shadow evaluation。
- 返回 Jarvis 只读解释 payload。

### 3.2 禁止做的事

- 不复用热点模型 signal 作为新的记忆信号。
- 不把 `memory_entity` 当推荐信号。
- 不直接采集 provider。
- 不直接读取 `raw_*`。
- 不绕过 source preflight。
- 不用 provider 原始 feed 当模型事实。
- 不用 GPT 推断、0、空字符串、mock 或 sample payload 补齐缺口。
- 不反写前端、Jarvis、学习权重或其他模型事实。
- 不让 pending outcome、post-hoc-only 样本、`new_independent_cycle` 进入正式 evolution 成功样本。

---

## 4. 与热点模型的关系

候选记忆模型的输入来源可以来自热点链路，但它不是热点模型的延续打分。

正确关系是：

```text
热点 mature sample / source signal
-> memory_seed
-> memory_entity
-> 后续候选记忆模型独立判断
```

关键边界：

- 热点 signal 只能作为历史来源证据。
- memory entity 只是记忆实体，不是信号。
- 正式二次激活必须生成新的 `memory_signal_id`。
- 候选记忆 release gate 不得复用热点 release gate。
- 候选记忆 outcome / evolution 不得混入热点模型训练真相。

---

## 5. 核心状态流

```text
hot mature sample / source signal
-> memory_seed
-> memory_entity
-> source_feature_snapshot
-> feature_readiness_audit
-> pre_signal_feature_window
-> pre_signal_case
-> activation_case
-> release_gate
-> memory_signal_fact contract
-> buy_point
-> observation / latest_state projection
-> mature outcome
-> up_reason_attribution
-> failure_attribution
-> evolution sample
-> TTL / threshold calibration
-> model version shadow evaluation
```

关键原则：

- `latest_state` 只作为投影，不是训练真相。
- outcome 未成熟不得提前进入训练成功样本。
- post-hoc-only 样本不得进入正式 evolution 成功样本。
- `new_independent_cycle` 不得进入正式 evolution 成功样本。

---

## 6. 重要状态

候选记忆模型中的核心状态包括：

- `blocked_data_gap`
- `memory_watch`
- `memory_active`
- `memory_reactivated`
- `memory_invalidated`
- `memory_decayed`
- `pre_signal_detected`
- `activation_watch`
- `activation_blocked`
- `official_signal_passed`
- `research_only_blocked`
- `buy_point_confirmed`
- `buy_point_blocked`
- `closed_ready_for_shadow_evaluation`

| 状态 | 含义 |
|---|---|
| `blocked_data_gap` | 关键数据缺失或时间合同失败 |
| `memory_watch` | 进入记忆观察，但证据尚不足 |
| `memory_active` | 记忆仍有效，存在趋势或结构延续 |
| `memory_reactivated` | 记忆对象出现二次激活迹象 |
| `memory_invalidated` | 结构失效或风险过高 |
| `memory_decayed` | 记忆过期或衰减 |
| `pre_signal_detected` | 检测到前置信号 |
| `activation_watch` | 进入激活观察 |
| `activation_blocked` | 激活被阻断 |
| `official_signal_passed` | official release gate 通过 |
| `research_only_blocked` | 只允许研究，不允许 official |
| `buy_point_confirmed` | 买点参考确认 |
| `buy_point_blocked` | 买点参考被阻断 |
| `closed_ready_for_shadow_evaluation` | 闭环成熟，可进入 shadow evaluation |

---

## 7. 输入数据

统一请求：

```json
{
  "row": {},
  "as_of_time_utc": "datetime|null",
  "run_id": "string|null"
}
```

### 7.1 记忆身份

- `memory_id`
- `memory_entity_id`
- `memory_seed_id`
- `appearance_id`
- `appearance_count`

### 7.2 热点来源

- `first_source_model`
- `source_model`
- `hot_signal_id`
- `first_source_signal_id`
- `first_outcome_label`

### 7.3 候选审计

- `ingest_mode=external_ths_model`
- `contract_audit_status=passed`
- `batch_id`
- `latest_batch_id`
- `candidate_id`
- `latest_candidate_id`

### 7.4 标的

- `instrument_id`
- `symbol`
- `name`

### 7.5 教师先验

- `p_limit_up`
- `max_p_limit_up`
- `p_limit_up_source`

这里的同花顺概率只是历史候选来源证据或上下文，不是候选记忆模型的独立推荐信号。

### 7.6 行情和特征

- `daily_bars`
- `price_path`
- `stock_rank`
- `moneyflow_context`
- `sector_theme_context`
- `tradability_context`

### 7.7 年龄和 TTL

- `memory_age_days`
- `candidate_memory_age_days`
- `days_since_last_candidate`
- `ttl_days`
- `ttl_remaining_days`
- `ttl_health_score`

缺交易日历年龄时必须：

```text
memory_age_days=null
state=blocked_data_gap
source_gap:missing_trading_calendar_memory_age
```

### 7.8 事件

`events[]` 中每条事件必须至少有以下任一时间字段，才能作为 ex-ante 证据：

- `available_at`
- `published_at`
- `captured_at`

当前事件源只能来自：

```text
source.event_news_v1
```

或后续编排层等价 source 输出。

Baidu Finance `finance_news_feed` 是 research-only 主源，CNINFO 为备源登记。

事件输入需保留：

- `title`
- `published_at`
- `available_at`
- `event_type`
- `url`
- `source_quality_status`
- `lineage_id`

---

## 8. 兼容评分

旧兼容评分公式：

```text
memory_hit_8pct_score =
0.20*historical
+0.25*trend
+0.20*accumulation
+0.20*second_wave
+0.15*upside
-0.30*breakdown
```

### 8.1 旧评分状态规则

| 条件 | 状态 |
|---|---|
| 有硬阻断 | `blocked_data_gap` |
| 缺评分分量 | `memory_watch` |
| `breakdown_failure_risk >= 70` | `memory_invalidated` |
| `second_wave_setup_score >= 70` 且 `breakdown < 45` 且 `memory_age_days` 在 5-20 且结构证据数至少 2 | `memory_reactivated` |
| `trend >= 60` 且 `breakdown < 50` | `memory_active` |
| `memory_age_days > 30` | `memory_decayed` |

---

## 9. 生产 release gate

### 9.1 official 条件

进入 official gate 至少需要：

```text
activation_quality_score >= 70
ttl_health_score >= 25
```

同时必须满足：

- 不存在 `data_time_contract_failed`
- source preflight 通过
- 生成新的 `memory_signal_id`
- 不复用 `memory_entity_id`
- 不复用热点 signal

### 9.2 阻断条件

以下情况阻断 official：

- `activation_quality_score` 不足。
- TTL 健康度不足。
- 数据时间合同失败。
- source preflight 不通过。
- 事件缺 `available_at`。
- 事件 `available_at` 晚于决策时间。
- 必要 feature 不新鲜。
- fresh moneyflow 或 sector theme 不满足。
- 未生成新的 `memory_signal_id`。

---

## 10. 校准阈值

| 项目 | 阈值 |
|---|---|
| matched control 最少样本 | `10` |
| TTL calibration 最少成熟样本 | `20` |
| pre-signal threshold calibration 默认值 | `62` |
| activation threshold calibration 默认值 | `68` |
| 每桶最少样本 | `5` |
| final acceptance 最少样本 | `8` |

---

## 11. 缺口码和阻断

### 11.1 兼容评分硬阻断

- `public_limitup_draft_not_allowed`
- `invalid_candidate_ingest_mode`
- `missing_production_candidate_batch`
- `missing_production_candidate_item`
- `contract_audit_not_passed`
- `missing_paid_ths_prior`
- `missing_instrument_identity`
- `missing_daily_price_path`
- `missing_trading_calendar`
- `missing_trading_calendar_memory_age`
- `invalid_trading_calendar_memory_age`

### 11.2 生产缺口和阻断

- `source_gap:daily_bar_20d`
- `source_gap:daily_ohlc_invalid`
- `source_gap:moneyflow_stock_rank`
- `source_gap:event_missing_available_at`
- `source_gap:event_future_available_at`
- `future_feature_watermark:{feature}`
- `required_feature_not_fresh:{feature}`
- `activation_requires_fresh_moneyflow_or_sector_theme`
- `ttl_not_healthy_for_official_signal`
- `activation_quality_below_official_gate`
- `data_time_contract_failed`
- `release_gate_not_passed`
- `unsupported_memory_buy_point_stage`
- `outcome_not_mature`
- `new_independent_cycle_excluded`

缺口必须保留，不得补 0 或空字符串。

---

## 12. source preflight

official release 前必须通过：

```text
POST /source/release/preflight
```

当 preflight 返回：

```text
can_release_official_signal=false
```

候选记忆模型不得发布 official。

事件、行情、资金、板块、交易状态等证据必须来自经过以下校验的 `source.*`：

- source build
- quality_status
- lineage
- `available_at`

### 12.1 事件新闻口径

`source.event_news_v1` 的 Baidu Finance 新闻只作为：

- 候选记忆事件上下文
- ex-ante 审计证据
- research-only 证据

它不是当前 official release hard gate。

如果事件缺失：

```text
available_at
```

必须保留：

```text
source_gap:event_missing_available_at
```

如果事件 `available_at` 晚于决策时间，必须保留：

```text
source_gap:event_future_available_at
```

不得用以下内容补齐：

- provider 原始 feed
- GPT 推断
- 0
- 空字符串
- sample payload

本服务不得直接调用 Baidu、CNINFO、AKShare 或其他 provider。

---

## 13. API 入口

### 13.1 健康检查

```text
GET /health
GET /healthz
GET /readyz
```

### 13.2 兼容入口

```text
POST /score
```

说明：

```text
/score 是旧评分合同兼容入口
正式链路以 /production/* 分阶段入口为准
```

### 13.3 生产阶段入口

```text
POST /production/seed/build
POST /production/entity/build
POST /production/source/features/build
POST /production/features/readiness
POST /production/pre-signal/window
POST /production/pre-signal/detect
POST /production/activation/evaluate
POST /production/release-gate/evaluate
POST /production/buy-point/evaluate
POST /production/outcomes/mature
POST /production/up-reason/build
POST /production/evolution/build
POST /production/events/standardize
POST /production/registry/upsert
POST /production/observations/bulk
POST /production/observations/due-plan
POST /production/matched-control/uplift
POST /production/ttl-calibration/build
POST /production/pre-limitup/analyze
POST /production/schedule/contract
POST /production/persistence/plan
POST /production/pre-signal/threshold-calibration
POST /production/replay/multi-day
POST /production/phase4/acceptance
POST /production/closure/run
POST /production/failure-attribution/build
POST /production/model-version/shadow-evaluate
POST /production/phase5/final-acceptance
```

说明：

```text
/production/closure/run 是 side-effect free 闭环验证
不替代生产分阶段调度
```

---

## 14. 统一响应

统一响应结构：

```json
{
  "model_name": "candidate_memory",
  "model_version": "candidate_memory_v1",
  "structured_output": {},
  "jarvis_payload": {},
  "contract_gaps": []
}
```

主要 `structured_output`：

- `contract`
- `memory_seed`
- `memory_entity`
- `source_feature_snapshot`
- `feature_readiness_audit`
- `pre_signal_feature_window`
- `pre_signal_case`
- `activation_case`
- `release_gate`
- `buy_point`
- `outcome_label`
- `up_reason_attribution`
- `failure_attribution`
- `evolution_sample`
- `active_case_registry`
- `bulk_observation_result`
- `due_observation_plan`
- `ttl_calibration_report`
- `matched_control_uplift`
- `model_schedule_contract`
- `stage_persistence_plan`
- `closure_pipeline`
- `model_version_shadow_evaluation`
- `phase5_final_acceptance`

Jarvis payload 只读，不得修改：

- 状态
- 分数
- 标签
- 模型事实
- release gate
- 学习权重

---

## 15. 落库合同

当前服务本身不直接写生产数据库。

持久化由编排 / 仓储层执行。

目标 SQL 文件：

- `infra/sql/0003_decision_memory_model_v1.sql`
- `infra/sql/0004_decision_memory_phase2_research_calibration.sql`
- `infra/sql/0005_decision_memory_phase3_production_repository_and_schedule.sql`
- `infra/sql/0006_decision_memory_phase4_production_chain_acceptance.sql`
- `infra/sql/0007_decision_memory_phase5_closed_loop_finalization.sql`
- `infra/sql/bootstrap_schema.sql`
- `packages/db-schema/alembic/versions/0001_current_baseline.py`

目标 `decision_memory.*` 合同包括：

- `decision_memory.memory_seed_v1`
- `decision_memory.memory_entity_v1`
- `decision_memory.memory_initial_snapshot_v1`
- `decision_memory.memory_observation_snapshot_v1`
- `decision_memory.memory_price_structure_feature_v1`
- `decision_memory.memory_moneyflow_feature_v1`
- `decision_memory.memory_sector_theme_feature_v1`
- `decision_memory.memory_event_signal_feature_v1`
- `decision_memory.memory_pre_signal_feature_window_v1`
- `decision_memory.memory_pre_signal_case_v1`
- `decision_memory.memory_activation_case_v1`
- `decision_memory.memory_score_fact_v1`
- `decision_memory.memory_release_gate_audit_v1`
- `decision_memory.memory_signal_fact_v1`
- `decision_memory.memory_buy_point_v1`
- `decision_memory.memory_monitoring_snapshot_v1`
- `decision_memory.memory_outcome_label_v1`
- `decision_memory.memory_up_reason_attribution_v1`
- `decision_memory.memory_pre_limitup_signal_analysis_v1`
- `decision_memory.memory_failure_attribution_v1`
- `decision_memory.memory_evolution_sample_v1`
- `decision_memory.memory_ttl_calibration_v1`
- `decision_memory.memory_model_version_evaluation_v1`
- `decision_memory.memory_active_case_registry_v1`
- `decision_memory.memory_latest_state_v1`
- `decision_memory.memory_model_version_shadow_evaluation_v1`

当前 `bootstrap_schema.sql` 也包含：

```text
decision.candidate_memory_*
```

兼容事实表。

运行事实以当前容器和 `bootstrap_schema.sql` 为准。

如果 `decision_memory.*` 合同表未在运行库出现，不能由 README 声称已经持久化。

---

## 16. 调度

### 16.1 scheduler 任务

| task_code | endpoint |
|---|---|
| `memory.seed.from_hot_signals` | `POST /production/seed/build` |
| `memory.pre_signal.scan` | `POST /production/pre-signal/detect` |
| `memory.release_gate.close` | `POST /production/release-gate/evaluate` |
| `memory.buy_point.next_session_reference` | `POST /production/buy-point/evaluate` |
| `memory.observe.outcome.evolution` | `POST /production/outcomes/mature` |

### 16.2 调度时间

| 阶段 | 时间 |
|---|---|
| seed / entity | 热点 official signal 和 observation 成熟后 |
| pre-signal | `15:55` 收盘确认，可选 `10:30` 研究扫描 |
| release gate | `16:05` |
| buy point | 下一交易日 `09:30-10:00` 评估窗口 |
| observation / outcome / evolution | 每日 `15:50` 加 T+5 / T+20 / T+40 成熟检查 |

---

## 17. 下游消费边界

| 下游 | 边界 |
|---|---|
| scheduler | 触发 owner endpoint，不改模型事实 |
| source-data-service | 提供 source row、lineage、quality、preflight |
| research-service / 编排层 | 组装真实输入、处理行级异常、持久化模型事实 |
| research-data-mart | 只读消费或同步 |
| data-inspector | 巡检 source、模型 ready 和闭环缺口 |
| execution-timing | 后续买点 / 时序评估，只读消费 |
| gateway / frontend | 只读展示 |
| Jarvis | 只读解释和提醒 |

---

## 18. 异常兜底

owner API 内部无法评分时返回：

```text
422
```

批处理编排层必须把单条异常转为行级研究事实。

### 18.1 warning

```text
candidate_memory:row_failed:{symbol}:score:{error_code}
```

### 18.2 状态

```text
memory_state=blocked_data_gap
publication_state=blocked
memory_hit_8pct_score=null
```

### 18.3 缺口

```text
source_gap:model_service_scoring_failed
source_gap:model_service_exception:{error_code}
```

### 18.4 payload 必须保留

- `stage`
- `run_id`
- `symbol`
- `instrument_id`
- `error_code`
- `error_message`
- 输入引用

状态变化必须写：

```text
candidate_memory_state_history
transition audit
```

`ad_hoc:*` 触发也不能丢状态。

单条失败不得拖垮整批。

---

## 19. 验收

### 19.1 定向测试

```bash
python -m pytest -q services/models_services/candidate-memory-service/tests
python -m pytest -q tests/test_candidate_memory_sql_contract.py tests/test_candidate_memory_phase3_sql_contract.py tests/test_candidate_memory_phase4_sql_contract.py tests/test_candidate_memory_phase5_sql_contract.py
```

### 19.2 跨服务验收

```bash
python scripts/core_services_acceptance.py --require-postgres
python scripts/core_services_acceptance.py --require-postgres --source-quality-matrix
```

真实 provider probe 由 source-data-service 和验收脚本执行。

本服务不得绕开 source orchestration 直接探 provider。

---

## 20. 当前闭环结论

当前候选记忆 owner service 已实现：

- API。
- 兼容评分。
- 生产分阶段合同。
- 事件 ex-ante 防后视镜。
- release gate。
- 买点。
- mature outcome。
- failure attribution。
- TTL / 阈值校准。
- matched control。
- shadow evaluation。

2026-06-14 本地 Docker 闭环中：

```bash
scripts/core_services_acceptance.py --require-postgres --real-provider-probe --source-quality-matrix
```

返回 0。

`memory.release_gate.close` 经 scheduler live dispatch 到本服务返回 200。

source release preflight 结果：

```text
can_release_official_signal=true
coverage_status=passed
freshness_status=passed
blocking_reasons=[]
```

验收样例中出现的 `source_gap:*` 属候选记忆行级审计语义，脚本 required checks 仍全部通过，不能被 scheduler 或本服务改写为事实。

Baidu `source.event_news_v1` 已通过 source-data-service 真实 raw/source/lineage 写入验证，但在本模型中仍只作为：

```text
events[]
research-only ex-ante 证据上下文
```

不参与 official hard gate。

当前最小闭环依赖：

- source-data-service
- scheduler-service
- 后续持久化编排

未阻断优化项见根目录：

```text
需优化点.MD
```

---

## 21. 一句话总结

候选记忆模型是研究热点候选离开短窗口后是否出现延迟兑现、二波、慢趋势或失效风险的二次激活模型：它从热点成熟样本或 source signal 生成 memory seed/entity，但不复用热点 signal；每次 official 二次激活必须生成新的 `memory_signal_id`，并经过 pre-signal、activation、release gate、buy point、observation、outcome、归因、TTL/阈值校准和 shadow evaluation 闭环；所有 official 都必须通过 `/source/release/preflight`，事件、行情、资金、板块和交易状态必须有 source build、lineage、quality_status 和 `available_at`，缺口保留，不补 0、不 mock、不绕过 source-data-service。
