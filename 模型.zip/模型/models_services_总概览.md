# models_services README（整理版）

本文件是 `services/models_services` 目录的集合层事实源，只记录模型服务集合层的当前设计、边界、调度、数据合同和验收口径。

- 全局硬约束以项目根目录 `AGENTS.md` 为准。
- 各模型子服务的细节事实源以各自目录 `README.md` 为准。
- 集合层数据资产账本见 `services/models_services/DATA_ASSETS.md`。
- 各模型子服务的数据资产账本见对应目录 `DATA_ASSETS.md`。

---

## 1. 当前服务总览

| 服务 | 端口 | 当前版本 / 合同 | 定位 |
|---|---:|---|---|
| `hot-candidates-service` | `8031` | `hot_candidates_v1` 兼容评分；`hot_candidates_v2_lifecycle` 生产阶段合同 | 消费 `source.ths_paid_limit_up_probability_v1` 的同花顺付费次日概率教师先验，识别 T+1/T+5/T+20 短窗口兑现机会 |
| `candidate-memory-service` | `8032` | `candidate_memory_v1` | 历史热点候选记忆，识别延迟兑现、二波、慢趋势和失效风险 |
| `ambush-watchlist-service` | `8033` | `ambush_watchlist_effective_turn_v1_1`；Phase2/3/4 分阶段版本 | 深圳 A 股低位潜伏抬头 / 龙抬头结构扫描 |
| `t-board-relay-service` | 容器 `8034` / 宿主默认 `8035` | `t_board_relay_v1` | T 字板主导资金博弈，识别 Day1 T 字板、Day2 开盘后 5 分钟滚动接力触发、买入后封板维护和 Day3 去留 |

---

## 2. 当前仓库边界

### 2.1 当前已包含的源码目录

当前仓库本体包含：

- `services/models_services/*`：模型 owner service。
- `services/source-data-service`：数据源服务和 worker。
- `services/scheduler-service`：调度服务。
- `services/data-inspector-service`：按新 source/preflight/lineage、模型 ready 和 scheduler ready 重新设计的数据巡检、缺口审计和 remediation task。
- `services/research-service`：按 `research_model_payload_assembler_v1` 从已构建的 `source.*` 和允许的上游模型事实组装 owner payload，或返回 `blocked_data_gap`。
- `packages/db-schema`：SQL bootstrap 工具。

### 2.2 当前仍未包含的源码目录

当前仓库本体仍不包含：

- `research-data-mart`
- `gateway-service`
- `execution-timing-service`
- `dynamic-feature-service`

因此，本目录 README 不得把正式 data mart 同步、买点版本链、动态特征服务和前端展示描述成“当前仓库已源码完成”。

### 2.3 当前闭环内的职责分工

在当前仓库闭环中：

| 组件 | 当前职责 |
|---|---|
| `source-data-service` | source preflight、provider probe、raw ingest、source build、lineage |
| `scheduler-service` | 已接入模型的 time wheel、preflight gate、dispatch 守卫、live dispatch |
| `research-service` | 组装真实模型输入 payload，缺事实时返回 `blocked_data_gap` |
| `data-inspector-service` | 数据巡检、缺口审计、remediation task |
| 模型 owner service | 接收已组装 payload，执行模型阶段合同，返回结构化输出 |

---

## 3. 模型 owner service 统一原则

所有模型服务都是 owner service：

1. 只接收已经组装完成的业务 payload。
2. 只执行模型合同计算，并返回结构化结果。
3. 不直接并发调用 BaoStock、AKShare、Tencent、Tushare、EastMoney、Baidu、CNINFO 等 provider。
4. 不直接读取 `raw_*`。
5. 不直接修改前端、Jarvis、交易、学习权重或人工状态。
6. 不用 sample payload、mock、空字符串、0 或推断值补真实数据缺口。
7. 缺真实数据、缺 `available_at`、未来数据、模型阶段阻断和异常兜底必须保留缺口码、阻断状态或 warning。

---

## 4. 跨服务数据流

### 4.1 当前最小闭环

```text
source-data-service provider probe / raw ingest / source build / lineage
-> /source/release/preflight
-> scheduler-service task plan / live dispatch
-> 已接入模型 owner service API
-> owner service structured_output / contract_gaps / jarvis_payload
```

### 4.2 目标生产主线

```text
provider / market / candidate facts
-> source-data-service raw/source/lineage
-> research-service 组装真实输入并持久化模型事实
-> 模型服务评分和 release gate
-> research-data-mart / data-inspector / scheduler / execution-timing / gateway / frontend / Jarvis 只读消费或调度
```

### 4.3 sample payload 与生产 payload 的边界

- scheduler sample payload 只用于请求体包装和 owner API 连通性验证。
- 当前验收不能用 scheduler sample payload 代替市场事实。
- 生产 payload 必须由 `research-service` 标记：
  - `payload_assembly_contract=research_model_payload_assembler_v1`
  - `payload_assembly_status=assembled_research_payload`
- official signal 必须同时满足：
  - 模型 release gate
  - `source-data-service /source/release/preflight`

---

## 5. 统一 API 合同

所有 owner service 均提供：

```text
GET /health
GET /healthz
GET /readyz
```

统一响应主体包含：

```json
{
  "model_name": "hot_candidates|candidate_memory|ambush_watchlist|t_board_relay",
  "model_version": "string",
  "structured_output": {},
  "jarvis_payload": {},
  "contract_gaps": []
}
```

### `contract_gaps` 口径

`contract_gaps` 是事实记录，不是错误吞噬区。

必须进入 `contract_gaps`、阻断状态或 warning 的情况包括：

- 缺真实数据。
- 缺 `available_at`。
- 出现未来数据。
- 模型阶段被阻断。
- 异常兜底。
- 缺关键 P0/P1 字段。
- source 覆盖度、freshness、quality_status、lineage 不满足合同。

不得用以下方式掩盖缺口：

- `0`
- 空字符串
- mock 值
- 推断值
- sample payload
- 前端临时生成事实

---

## 6. source preflight 合同

模型服务 release gate / official 动作前必须调用：

```text
POST /source/release/preflight
```

preflight 必须同时检查：

- 模型 source 覆盖度
- freshness
- P0 字段
- quality_status
- lineage
- `available_at`

当返回 `can_release_official_signal=false` 时：

- 禁止发布 official signal。
- P1 degraded 可作为非阻断风险保留。
- 不得在界面或报告中伪装成完整覆盖。

### 6.1 事件新闻源

`source.event_news_v1` 当前口径：

- 主源：Baidu Finance `finance_news_feed`
- 备源：CNINFO
- 字段：`title/published_at/available_at/event_type/url`
- 定位：research-only 的 ex-ante 证据上下文和审计材料
- 当前不是 P0 official release hard gate

缺事件新闻时：

- 保留缺口码或空态。
- 不得把 provider feed 直接当模型事实。
- 不得绕过 source build、quality_status、lineage 和 `available_at` 校验。

### 6.2 模型四 P0 事实

模型四 `t_board_relay` P0 需要：

- `source.daily_bar_v1`
- `source.limit_price_v1`
- `source.limit_event_v1`
- `source.trade_status_v1`
- `source.realtime_quote_v1.float_market_cap`
- `source.minute_bar_v1`
- `source.trade_tick_v1`
- 动态特征 bundle：`t_board_relay_intraday_bundle_v1`

当前已知状态：

- `000759.SZ / 2026-06-12` 已完成真实 source 标准层复核。
- `t_board_relay/day1_scan` 与 `t_board_relay/day2_trigger` preflight 均通过。
- owner service 只接收这些事实作为输入合同。
- 当前未落地独立 `dynamic-feature-service` 源码。
- 缺 `t_board_relay_intraday_bundle_v1` 时必须保留缺口码，不得补 0、mock 或推断值。

---

## 7. scheduler 调度合同

### 7.1 调度服务代码入口

```text
services/scheduler-service/src/scheduler_service/hot_plan.py
services/scheduler-service/src/scheduler_service/three_model_plan.py
services/scheduler-service/src/scheduler_service/three_model_dispatch.py
services/scheduler-service/src/scheduler_service/runtime.py
```

### 7.2 关键 API

```text
GET /scheduler/plan/three-models
GET /scheduler/validate/three-models
GET /scheduler/materialize/three-models
GET /scheduler/live-dispatch/sample/{task_code}
GET /scheduler/validate/live-dispatch-samples
POST /scheduler/trigger
```

### 7.3 `POST /scheduler/trigger` 口径

- 默认 `dry_run=true`。
- 非 dry-run 必须显式传入 `owner_endpoints`。
- scheduler 只以 owner service 的真实 2xx 响应作为 `accepted=true`。
- scheduler 不得伪造成功。

### 7.4 官方发布任务

当前官方发布任务只有三条：

| task_code | owner | endpoint |
|---|---|---|
| `hot.release_gate.preopen` | `hot-candidates-service` | `POST /production/release-gate/evaluate` |
| `memory.release_gate.close` | `candidate-memory-service` | `POST /production/release-gate/evaluate` |
| `ambush.phase3.release_gate.close` | `ambush-watchlist-service` | `POST /ambush/phase3/run` |

### 7.5 模型四 non-official 研究任务

模型四调度已写入 `scheduler-service`，全部为 non-official 研究 / 模型阶段任务：

| task_code | owner | endpoint |
|---|---|---|
| `t_relay.day1.scan.close` | `t-board-relay-service` | `POST /t-board-relay/day1/scan` |
| `t_relay.day2.watch.rolling_5m` | `t-board-relay-service` | `POST /t-board-relay/day2/watch` |
| `t_relay.day2.trigger.rolling_5m` | `t-board-relay-service` | `POST /t-board-relay/day2/trigger-check` |
| `t_relay.day2.post_entry.monitor` | `t-board-relay-service` | `POST /t-board-relay/post-entry/monitor` |
| `t_relay.day3.exit.open` | `t-board-relay-service` | `POST /t-board-relay/day3/exit-check` |
| `t_relay.day3.exit.tail` | `t-board-relay-service` | `POST /t-board-relay/day3/exit-check` |
| `t_relay.observation.monitor.snapshot_5m` | `t-board-relay-service` | `POST /t-board-relay/observation-monitor/snapshot` |
| `t_relay.live_result.compute_30m` | `t-board-relay-service` | `POST /t-board-relay/observation-monitor/snapshot` |
| `t_relay.outcome.build` | `t-board-relay-service` | `POST /t-board-relay/outcomes/build` |

模型四当前仍是研究模型：

- 所有 `t_relay.*` 调度任务均 `is_official_publish=false`。
- 不得误读为官方交易信号。
- 不反写前三模型。

---

## 8. 调度时间

### 8.1 热点模型

- 竞价冻结：`09:25:05,09:25:30`
- 盘前评分：`09:26:00,09:28:00,09:29:30`
- release gate 截止：`09:30:00`
- 开盘 5 分钟买点：`09:30-09:36`
- 盘中观察：`09:30-15:00`
- T+5/T+20 outcome 和离线 evolution：收盘后

### 8.2 候选记忆模型

- seed/entity：热点成熟样本后
- pre-signal 扫描：`15:55`
- 可选研究扫描：`10:30`
- release gate：`16:05`
- outcome/evolution：每日收盘后及 T+5/T+20/T+40

### 8.3 潜伏抬头模型

- source capability：周期审计
- 图库：离线挖掘
- Phase2：收盘后 `15:20`
- Phase3 release gate：`15:35`
- 观察/outcome/evolution：`15:55` 及成熟窗口

### 8.4 T 字板接力模型

Day1：

- `10:40/14:55/15:02/15:10` 通过 THS 公开涨停池构建 `source.limit_event_v1`。
- `15:12/15:20/15:30/15:35/15:45` 只对 T 字板阶段候选补交易状态、日线、涨跌停价和流通市值。
- owner 在 `15:05-15:30` 评估候选 T 字板和封单比例。

Day2：

- `09:25` 预加载。
- `09:30-10:30` 每 5 分钟滚动观察。
- 首次接近涨停后进入盘口确认。
- 仅 `order_consumption_side=ASK` 且 `order_consumption_amount>0` 表示卖盘被主动买盘扫掉，并触发接力机会提示。
- `order_consumption_side=BID` 表示主动卖出打买盘，作为风险 / 失效条件。
- 方向或金额缺失时等待确认或进入 `data_blocked`。
- 触发后到 `15:00` 执行封板维护监控。

观察台：

- `09:30-15:00` 每 5 分钟留存投影快照。
- `09:32-15:02` 每 30 分钟留存模型结果快照。

Day3：

- `09:25-09:35` 开盘涨停去留。
- `14:40-14:55` 尾盘未涨停退出研究事件。

---

## 9. 模型四观察台合同

模型四当前集合层合同如下：

### 9.1 Day2 触发前

- 由 `t_board_day2_watch_snapshot_v1` 五分钟滚动事实驱动普通用户观察台。
- Day2 未触发前展示观察状态，不得前端伪造模型事实。

### 9.2 触发确认

触发确认以“买盘主动扫掉卖盘”为主：

- `order_consumption_side=ASK` 且 `order_consumption_amount>0`：卖盘被主动买盘扫掉，触发接力机会提示。
- `order_consumption_side=BID`：卖盘主动砸向买盘，是风险 / 失效条件。
- 方向或金额缺失：等待确认或 `data_blocked`。

### 9.3 触发后封板维护

- 触发后按开盘时段每 5 分钟留存至收盘。
- 不得用投影快照覆盖真实阶段事实时间。

### 9.4 observation-board 输出

`observation-board` 同步输出：

- `model_score`
- `model_score_label`
- `score_state`
- `model_score_version=t_board_relay_observation_score_v1`

模型分由模型四 owner 基于阶段事实综合计算：

- 缺关键事实时 `model_score=NULL`。
- 不补 0。
- 前端只读消费 `observation-board` 投影和模型分降序。
- 前端不生成、不修改模型事实。

### 9.5 更新时间展示

前端 `更新` 列必须同时展示：

- 最后一次模型产出时间：
  - `last_model_output_at`
  - `model_evaluated_at`
- 最新真实抓取 / 阶段事实时间：
  - `latest_data_fetch_at`
  - `last_data_captured_at`

`latest_projection_snapshot_at` 只作审计，不得冒充真实抓取时间。

### 9.6 关键阻断规则

- Day2 `10:30` 后缺有效五分钟事实时必须落 `data_wait`。
- 不得继续显示“观察中”。
- `t_relay.observation.monitor.snapshot_5m` 每 5 分钟通过 `POST /t-board-relay/observation-monitor/snapshot` 留存 `projection_snapshot_5m`。
- `t_relay.live_result.compute_30m` 每 30 分钟留存 `model_result_30m`，写入 `model_evaluated_at/last_model_output_at`。
- 两者都 append-only 写入 `decision_t_relay.t_board_observation_monitor_snapshot_v1`。

---

## 10. source 高频窗口与模型输入边界

非临时 source 高频窗口已由：

- `scheduler-service` 的 `source_fetch_schedule_registry_v1`
- `scheduler_source_time_wheel_v1`

承担。

到点只提交：

```text
source-data-service /source/fetch/submit
```

真实 provider 并发仍由 source-data-worker 控制。

### 模型三扫描边界

- 模型三可以使用全 A 日频/日线底座做市场扫描。

### 模型四扫描边界

- 模型四 Day1 不做全 A 高频/报价盲扫。
- 模型四 Day1 先读 `source.limit_event_v1` 的涨停池 / T 字板候选。
- 再对候选级补 P0 事实。

### owner 输入边界

- 模型 owner 任务仍只接收已组装业务 payload。
- `research-service` 负责组装。
- scheduler 负责任务定义、交易日实例化、dry-run、source time wheel、payload preflight 和已接入模型 live dispatch。
- scheduler 不伪造模型输入或模型事实。

---

## 11. 当前持久化口径

当前 SQL 文件包含三类合同：

### 11.1 目标独立域合同

```text
infra/sql/0002_source_decision_hot_refactor.sql
infra/sql/0003~0007
infra/sql/0008~0010
```

定义：

- `decision_hot.*`
- `decision_memory.*`
- `decision_ambush.*`
- 其他分阶段目标表

### 11.2 当前 bootstrap 基线

```text
infra/sql/bootstrap_schema.sql
```

这是当前运行容器和 schema-bootstrap 的实际基线输出。

### 11.3 当前 Alembic 入口

```text
packages/db-schema/alembic/versions/0001_current_baseline.py
```

职责：

- 委托执行 `infra/sql/*.sql`
- 使 AGENTS 约定的基线文件真实存在

### 11.4 差异处理原则

如果 `bootstrap_schema.sql` 与分阶段 SQL 文件出现差异：

- 运行事实以当前容器、当前代码和 `bootstrap_schema.sql` 为准。
- 差异必须在下一轮 schema 同步中修正。
- 不能靠 README 声称已经落库。

---

## 12. 验收入口

### 12.1 核心闭环验收

```bash
python scripts/core_services_acceptance.py --require-postgres
```

### 12.2 最高规格数据质量验收

```bash
python scripts/core_services_acceptance.py --require-postgres --source-quality-matrix
python scripts/core_services_acceptance.py --require-postgres --real-provider-probe
```

### 12.3 数据源生产拍板验收

```bash
python scripts/source_data_acceptance.py --require-postgres
```

### 12.4 验收结果解释

上述脚本返回 0 代表：

- 当前最小闭环服务合同调通。

不代表：

- scheduler 已写入官方信号。
- 当前仓库已包含 data-mart/gateway/execution-timing 的完整源码闭环。
- `research-service` 替代了 research-data-mart、execution-timing 或模型 owner 的评分/发布职责。

---

## 13. 禁止反写与禁止伪造

### 13.1 scheduler 禁止项

scheduler 不写：

- 模型事实
- 分数
- 状态
- 标签
- 发布闸门
- 买点版本
- 学习权重

### 13.2 gateway / frontend / Jarvis / explanation 禁止项

这些组件只能：

- 只读展示
- 解释
- 翻译
- 提醒

不得：

- 生成模型事实
- 修改模型事实
- 修改模型分数
- 修改模型状态

### 13.3 模型 owner service 禁止项

模型 owner service 不得：

- 直接并发抓取 provider
- 直接读取 raw
- 跳过 source preflight
- 把 sample payload 当 source 事实
- 用 0、空字符串、mock 或推断值补齐真实缺口

### 13.4 缺失数据处理原则

缺失真实数据必须保留：

- `NULL`
- 缺口码
- 阻断状态
- warning
- 空态

---

## 14. 当前闭环结论

当前已锁定：

- 三模型 owner service
- 模型四 owner service
- source-data-service
- source-data-worker
- data-inspector-service
- scheduler-service

并已具备最小：

- Docker
- Postgres
- source preflight
- live dispatch
- inspection

闭环。

### 14.1 2026-06-14 本地复核结论

使用：

```text
000063.SZ + 000759.SZ / 2026-06-12
```

完成真实复核后：

- `source.trade_status_v1`
- `source.adjusted_daily_bar_v1`
- `source.stock_moneyflow_daily_v1`

已对 `000759` 补齐 raw/source/lineage。

以下模型均通过：

- `hot_candidates.preopen_release_gate`
- `candidate_memory.outcome_label`
- `ambush_watchlist.release_gate`

结果：

- `can_release_official_signal=true`
- coverage/freshness passed
- `blocking_reasons=[]`
- `degraded_reasons=[]`

模型四：

- `t_board_relay/day1_scan` preflight passed
- `t_board_relay/day2_trigger` preflight passed

巡检与调度：

- `data-inspector-service` `startup_guard/core_closure` 均 ready
- gap 0
- `scheduler-service /readyz` closure_guard ready
- `/source/fetch/queues/summary` 全队列 queued/leased/dead-letter 均为 0

验收脚本结果：

```bash
python scripts/source_data_acceptance.py --require-postgres --real-provider-probe --probe-limit 0 --quality-matrix
```

返回 0。

```bash
python scripts/source_data_quality_matrix.py --symbol 000063.SZ,000001.SZ,600000.SH,000759.SZ --trade-date 2026-06-12 --table daily --table adjusted
```

返回 0。

```bash
python scripts/core_services_acceptance.py --require-postgres --real-provider-probe --source-quality-matrix --source-quality-symbol 000063.SZ,000001.SZ,600000.SH,000759.SZ --source-quality-trade-date 2026-06-12
```

返回 0。

### 14.2 2026-06-17 后续解锁

已新增：

- 非临时 source 调度注册
- source time wheel
- 临时取数转交入口

所有 source fetch 仍只进入：

```text
source-data-service orchestration
```

### 14.3 Baidu Finance 事件新闻口径

Baidu Finance 事件新闻保持 research-only。

probe 出参必须是：

```text
usable_for_model_online=false
usable_for_research_only=true
```

不改变 official release gate。

### 14.4 模型四当前状态

`t-board-relay-service` 当前已落地：

- 独立 owner service
- Day1/Day2/Day3 状态机
- Postgres append-only repository
- `decision_t_relay` / `research_t_relay` schema
- scheduler non-official live dispatch
- data-inspector 巡检域

仍未落地：

- 独立 `dynamic-feature-service` 源码

因此，动态特征服务相关缺口不阻断当前 Day1/Day2 source、调度、repository 和巡检闭环，但必须保留缺口码，不得伪造完整事实。

### 14.5 当前未阻断优化项

当前未阻断项记录在根目录：

```text
需优化点.MD
```

包括：

- AKShare/EastMoney research-only 恢复
- 指数成交量口径归一
- P1 资金流扩大样本与多源口径校准
- Baidu 事件新闻覆盖率 / 分类质量扩样
- 模型四动态特征服务独立化
