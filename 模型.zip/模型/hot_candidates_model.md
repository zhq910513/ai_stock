# 热点模型归类总结

## 1. 模型定位

`hot-candidates-service` 是热点模型 `hot_candidates` 的独立 owner service。

它以：

```text
source.ths_paid_limit_up_probability_v1
```

中的同花顺付费次日涨停概率作为教师先验，再结合本地行情、竞价、资金、题材、市场环境、可交易性和 source 可见性，判断候选在 T+1 / T+5 / T+20 短窗口内是否具备可验证的方向兑现价值。

模型只输出：

- 研究信号
- 阶段评分
- release gate
- 评估基准价
- 买点参考
- observation
- outcome
- 失败归因
- evolution
- teacher calibration

模型不提供交易建议，不直接采集 provider，不直接读取 `raw_*`，不反写前端、Jarvis 或学习权重。

---

## 2. 当前版本

| 项目 | 当前值 |
|---|---|
| 模型名 | `hot_candidates` |
| 兼容评分版本 | `hot_candidates_v1` |
| 生产生命周期合同版本 | `hot_candidates_v2_lifecycle` |
| 生产 API 版本 | `hot_candidates_production_phase7_v1` |

---

## 3. 服务边界

### 3.1 允许做的事

- 接收 research-service 或编排层组装好的真实 payload。
- 消费已经进入 source 标准层的同花顺付费概率。
- 执行 source visibility audit。
- 执行阶段评分。
- 执行 release gate。
- 计算买点参考。
- 生成 observation。
- 生成 T+5 / T+20 outcome。
- 生成失败归因。
- 生成 evolution sample。
- 生成 teacher calibration 合同。
- 返回结构化输出和 Jarvis 只读解释 payload。

### 3.2 禁止做的事

- 不直接读取 Cookie。
- 不直接调用同花顺 provider。
- 不直接调用 Baidu、CNINFO、AKShare 或其他 provider。
- 不直接读取 `raw_*`。
- 不绕过 source preflight。
- 不用前端手填概率。
- 不用 0、随机值、旧 payload、mock、空字符串或 GPT 推断补教师先验。
- 不把 scheduler owner 2xx 当作 official signal 通过。
- 不修改前端、Jarvis、学习权重或其他模型事实。

---

## 4. 核心输入数据

### 4.1 `/score` 请求

```json
{
  "row": {},
  "as_of_time_utc": "datetime|null",
  "run_id": "string|null"
}
```

### 4.2 生产阶段请求

```json
{
  "payload": {},
  "as_of_time_utc": "datetime|null",
  "run_id": "string|null"
}
```

### 4.3 核心字段

#### 标的和候选

- `instrument_id`
- `symbol`
- `name`
- `batch_id`
- `candidate_id`
- `candidate_source=hot_candidates`

#### 教师先验

- `p_limit_up`
- `p_limit_up_source=source.ths_paid_limit_up_probability_v1`
- `p_limit_up_available_at`
- `p_limit_up_model_version`
- `p_limit_up_credential_version`

本服务只消费 source 标准层概率事实，不接收手填概率，不读 Cookie，不直接取同花顺接口。

#### source 时间线

- `candidate_available_at`
- `batch_available_at`
- `auction_snapshot.available_at`
- `stock_rank.available_at`
- `market_regime.available_at`
- `daily_bars[].available_at`

所有进入 official 阶段的数据必须满足：

```text
available_at <= decision_time
```

#### 行情和交易

- `daily_bars`
- `auction_snapshot`
- `minute_bars`
- `open_5m_vwap`
- `open_5m_available_at`
- `reference_entry_price`

#### 上下文

- `stock_rank`
- `theme_ranks`
- `market_regime_context`
- `news_events`
- `inspection`

其中 `news_events` 当前只能来自 source-data-service 构建后的：

```text
source.event_news_v1
```

Baidu Finance `finance_news_feed` 是 research-only 主源，CNINFO 是备源登记。

---

## 5. 教师先验合同

热点模型的教师先验唯一来源是：

```text
source.ths_paid_limit_up_probability_v1
```

### 5.1 source-data-service 职责

以下全部归 source-data-service 管：

- 同花顺付费概率抓取。
- Cookie 留存。
- Cookie probe。
- raw/source/lineage。
- 批次 deadline。
- 批次状态。
- 概率 source build。

### 5.2 hot-candidates-service 职责

本服务只做：

```text
消费已通过 source build 的概率事实
```

不做：

- Cookie 读取。
- Cookie 管理。
- provider 调用。
- 概率手填。
- 概率兜底生成。

### 5.3 Cookie 或概率缺失时的处理

当出现：

- Cookie 缺失。
- Cookie 失效。
- 接口不可取数。
- 概率尚未入库。

候选交易日的下一交易日 `09:00 Asia/Shanghai` 前保持阻断或等待缺口。

超过 deadline 后仍未补齐，且 source-data-service 批次状态为：

```text
abandoned_no_probability_before_deadline
```

该批候选进入放弃态。

不得用以下方式补教师先验：

- 0
- 手填
- 随机
- 旧 payload
- GPT 推断
- 前端输入
- mock 值

---

## 6. 状态流转

热点模型生产生命周期如下：

```text
candidate row
-> source_visibility_audit
-> hot_cycle_identity / hot_decision_case
-> stage_scores
-> release_gate
-> initial_decision_snapshot
-> hot_signal_fact contract
-> buy_point reference
-> observation snapshots
-> outcome label
-> failure attribution / first-output distortion
-> evolution sample / teacher calibration
```

关键原则：

- 首次决策快照不可覆盖。
- 第二次及以后 observation 必须 append-only。
- latest state 只能是投影，不是训练真相。
- release gate 必须依赖真实 source 与 preflight，而不是 sample payload。

---

## 7. 阶段分与 release gate

### 7.1 阶段分

热点模型包含四类阶段分：

- `pre_auction_score`
- `auction_confirmed_score`
- `open_5m_confirmed_score`
- `official_hot_score`

### 7.2 official 分数选择

```text
open_5m_confirmed_score 优先作为 official score
```

如果缺失，则使用：

```text
auction_confirmed_score
```

### 7.3 release gate 阈值

| 条件 | 结果 |
|---|---|
| `official_hot_score >= 60` 且无 hard block | 允许 official |
| `official_hot_score >= 50` 但未达 official | 进入 calibration / research |
| 不满足分数或存在 hard block | 阻断 official |

---

## 8. hard block

以下属于硬阻断：

- `evidence_available_after_decision_time`
- `missing_available_at_lineage`
- `missing_official_reference_stage_evidence`
- `one_word_limit_no_fill`
- `open_5m_available_after_calc_time`
- `auction_available_after_calc_time`
- `missing_reference_price`

出现 hard block 时，不得发布 official signal。

---

## 9. source 缺口与 warning

常见缺口包括：

- `source_gap:ths_paid_probability_missing`
- `source_gap:ths_paid_probability_cookie_expired`
- `source_gap:ths_paid_probability_batch_abandoned`
- `source_gap:candidate_pool_membership`
- `source_gap:instrument_identity`
- `source_gap:daily_bar_lookback`
- `source_gap:daily_ohlc_invalid`
- `source_gap:stock_moneyflow_rank`
- `source_gap:stock_moneyflow_rank_components`
- `source_gap:auction_confirmation`
- `source_gap:minute_trade_context`
- `source_gap:dynamic_signal_context`
- `source_gap:board_theme_context`
- `source_gap:news_event_context`
- `source_gap:market_regime_context`
- `source_gap:inspection_context`

缺口必须保留。

不得用：

- 0
- 空字符串
- mock
- 推断
- 旧 payload

补齐。

---

## 10. source preflight

official release 前必须调用：

```text
POST /source/release/preflight
```

当 source preflight 返回：

```text
can_release_official_signal=false
```

热点模型不得发布 official。

注意：

```text
scheduler owner 2xx 只表示调用成功
不代表 source gate 通过
不代表 official signal 已通过
```

---

## 11. 新闻事件上下文

当前新闻事件源：

```text
source.event_news_v1
```

来源口径：

- Baidu Finance `finance_news_feed`：research-only 主源。
- CNINFO：备源登记。

字段至少保留：

- `title`
- `published_at`
- `available_at`
- `event_type`
- `url`
- `source_quality_status`
- `lineage_id`

当前新闻事件只用于：

- 新闻事件上下文。
- 解释。
- 事后审计。
- research-only 证据。

当前不是热点 official release hard gate。

如果未来新闻事件要进入 official 评分、标签、买点或发布闸门，必须先由 source-data-service 完成：

- provider probe
- raw/source/lineage 写入
- coverage/freshness 规则
- README 覆盖

热点服务不得直接调用新闻 provider。

---

## 12. 主要 API

### 12.1 健康检查

```text
GET /health
GET /healthz
GET /readyz
```

### 12.2 兼容和研究入口

```text
POST /score
POST /observe
POST /evolution-sample
POST /distortion-report
POST /pipeline/run
POST /research-pool/classify
POST /teacher-calibration/report
```

说明：

```text
/pipeline/run 只用于 side-effect free 集成验证
不是生产 scheduler 主入口
```

### 12.3 生产阶段入口

```text
POST /production/cases/build
POST /production/features/build
POST /production/scores/compute
POST /production/release-gate/evaluate
POST /production/buy-point/evaluate
POST /production/observations/bulk
POST /production/outcomes/mature
POST /production/evolution/build
POST /production/failure-analysis/build
POST /production/teacher-calibration/version
```

---

## 13. 统一响应

响应统一包含：

```json
{
  "model_name": "hot_candidates",
  "model_version": "hot_candidates_v1|hot_candidates_v2_lifecycle",
  "structured_output": {},
  "jarvis_payload": {},
  "contract_gaps": []
}
```

### 13.1 主要 structured_output

| 接口 | 输出对象 |
|---|---|
| `/score` | `analysis`、`contract`、`research_contract` |
| `/production/cases/build` | `case_build` |
| `/production/scores/compute` | `score_compute` |
| `/production/release-gate/evaluate` | `release_gate_result` |
| `/production/buy-point/evaluate` | `buy_point_result` |
| `/production/observations/bulk` | `observations`、`count` |
| `/production/outcomes/mature` | `outcome_mature_result` |
| `/production/evolution/build` | `evolution_build_result` |
| `/production/failure-analysis/build` | `failure_analysis_result` |

### 13.2 Jarvis payload

Jarvis payload 只读解释。

不得通过 Jarvis 修改：

- 分数
- 状态
- 标签
- 模型事实
- release gate
- 学习权重

---

## 14. 落库合同

当前服务本身不直接写生产数据库。

持久化由编排 / 仓储层执行。

目标 SQL 文件：

- `infra/sql/0002_source_decision_hot_refactor.sql`
- `infra/sql/bootstrap_schema.sql`
- `packages/db-schema/alembic/versions/0001_current_baseline.py`

目标 `decision_hot.*` 合同包括：

- `decision_hot.hot_cycle_v1`
- `decision_hot.hot_cycle_day_snapshot_v1`
- `decision_hot.hot_decision_case_v1`
- `decision_hot.hot_evidence_snapshot_v1`
- `decision_hot.hot_feature_matrix_v1`
- `decision_hot.hot_score_fact_v1`
- `decision_hot.hot_initial_decision_snapshot_v1`
- `decision_hot.hot_release_gate_audit_v1`
- `decision_hot.hot_signal_fact_v1`
- `decision_hot.hot_buy_point_v1`
- `decision_hot.hot_observation_snapshot_v1`
- `decision_hot.hot_outcome_label_v1`
- `decision_hot.hot_failure_attribution_v1`
- `decision_hot.hot_first_output_distortion_analysis_v1`
- `decision_hot.hot_research_sample_pool_v1`
- `decision_hot.hot_teacher_calibration_v1`
- `decision_hot.hot_teacher_calibration_version_v1`
- `decision_hot.hot_evolution_sample_v1`
- `decision_hot.hot_model_version_evaluation_v1`

如果运行库只存在 `decision.*` 兼容事实表，则以当前 `bootstrap_schema.sql` 和运行容器为准。

不能靠 README 声称已落入不存在的表。

---

## 15. 调度

### 15.1 scheduler 任务

| task_code | endpoint |
|---|---|
| `hot.score.auction_confirmed` | `POST /production/scores/compute` |
| `hot.release_gate.preopen` | `POST /production/release-gate/evaluate` |
| `hot.buy_point.open_5m` | `POST /production/buy-point/evaluate` |
| `hot.observe.intraday` | `POST /production/observations/bulk` |
| `hot.outcome.t5_t20` | `POST /production/outcomes/mature` |
| `hot.evolution.offline` | `POST /production/evolution/build` |

### 15.2 调度时间

| 阶段 | 时间 |
|---|---|
| 竞价采集 | `09:15-09:25` |
| 竞价冻结 | `09:25:05, 09:25:30` |
| 热点评分 | `09:26:00, 09:28:00, 09:29:30` |
| release gate | `09:25:40, 09:28:40, 09:29:40`，截止 `09:30:00` |
| open 5m 买点 | `09:30-09:36` |
| observation | `09:30-10:00` 每 60 秒；`10:00-14:30` 每 300 秒；尾盘加密 |
| outcome | `15:10, 15:40` 加 T+5/T+20 |
| evolution | `18:30` 后 |

---

## 16. 下游消费边界

| 下游 | 边界 |
|---|---|
| scheduler | 触发 owner endpoint，不改模型事实 |
| source-data-service | 提供 source row、lineage、quality、preflight |
| research-service / 编排层 | 组装真实输入、处理行级异常、持久化模型事实 |
| research-data-mart | 只读消费或同步 |
| data-inspector | 巡检 source、模型 ready 和闭环缺口 |
| execution-timing | 后续买点/时序评估，只读消费 |
| gateway / frontend | 只读展示 |
| Jarvis | 只读解释和提醒 |

---

## 17. 异常兜底

owner API 内部无法评分时返回：

```text
422
```

批处理编排层必须把单条异常转为行级研究事实。

### 17.1 warning

```text
hot_candidates:row_failed:{symbol}:{stage}:{error_code}
```

### 17.2 状态

```text
state=blocked
hot_score=null
```

### 17.3 缺口

```text
source_gap:model_service_scoring_failed
source_gap:model_service_exception:{error_code}
```

### 17.4 payload 必须保留

- `stage`
- `run_id`
- `symbol`
- `instrument_id`
- `error_code`
- `error_message`
- 输入引用

单条失败不得拖垮整批。

---

## 18. 验收

### 18.1 定向测试

```bash
python -m pytest -q services/models_services/hot-candidates-service/tests
```

### 18.2 跨服务验收

```bash
python scripts/core_services_acceptance.py --require-postgres
python scripts/core_services_acceptance.py --require-postgres --source-quality-matrix
```

真实 provider probe 由 source-data-service 和验收脚本执行。

热点模型不得绕开 source orchestration 直接探 provider。

---

## 19. 当前闭环结论

当前热点 owner service 已实现：

- API。
- 阶段合同。
- source visibility hard block。
- release gate。
- 买点评估。
- outcome。
- 失败归因。
- evolution 合同。

2026-06-14 本地 Docker 闭环中：

```bash
scripts/core_services_acceptance.py --require-postgres --real-provider-probe --source-quality-matrix
```

返回 0。

`hot.release_gate.preopen` 经 scheduler live dispatch 到本服务返回 200。

source release preflight 结果：

```text
can_release_official_signal=true
coverage_status=passed
freshness_status=passed
blocking_reasons=[]
```

Baidu `source.event_news_v1` 已通过 source-data-service 真实 raw/source/lineage 写入验证，但在热点模型中仍只作为 `news_events` research-only 证据上下文，不参与 official hard gate。

当前最小闭环依赖：

- source-data-service
- scheduler-service
- 后续持久化编排

未阻断优化项见根目录：

```text
需优化点.MD
```

---

## 20. 拍板冻结口径

冻结对象：

```text
hot-candidates-service -> owner contract/frontend-readonly chain -> model1 closure evidence
```

冻结时间：

```text
2026-06-21
```

### 20.1 锁定范围

锁定内容包括：

- 热点候选 owner service API。
- 阶段合同。
- source visibility hard block。
- official release gate 必须经 `/source/release/preflight`。
- 同花顺付费概率只消费 `source.ths_paid_limit_up_probability_v1`。
- Cookie / 付费概率抓取 / 批次 deadline 均归 source-data-service。
- scheduler 热点计划。
- `#/model-hot` 只读展示链路当前合同证据。

### 20.2 当前运行事实

当前事实包括：

- `hot-candidates-service /readyz` 为 ready。
- scheduler `validate/hot-candidates` valid。
- scheduler `validate/hot-workflow` valid。
- scheduler `validate/source-schedule` valid。
- 前端 `#/model-hot` 可读取 `source.limit_event_v1` 并展示 105 条真实只读记录。
- 模型一单测和前端合同测试通过。
- 当前同花顺付费概率 Cookie 运行状态为 `configured=false/status=missing`。
- `2026-06-18` 候选批次为 `pending_cookie`。
- 87 只候选尚未抓取概率。
- deadline 为 `2026-06-22 09:00 Asia/Shanghai`。
- 该状态是付费 Cookie 缺失导致的源数据阻断，不得写成概率数据已产出。

### 20.3 允许的只读验收

允许读取：

- `/readyz`
- `/healthz`
- scheduler 热点校验接口
- source 付费概率 cookie/status
- source batch-status
- source 队列摘要
- `#/model-hot` 截图 / 可见文本检查

允许运行：

```bash
python -m pytest -q -p no:cacheprovider services/models_services/hot-candidates-service/tests
python -m pytest -q services/shence-frontend-service/tests/test_frontend_contract.py
```

### 20.4 禁止修改项

未经解锁不得修改：

- 本服务评分。
- release gate。
- 买点。
- observation。
- outcome。
- 失败归因。
- evolution 合同。
- source preflight 口径。
- 同花顺付费概率消费边界。
- Cookie 归属边界。
- scheduler 热点计划。
- 模型一 README / DATA_ASSETS 冻结事实。

不得让本服务：

- 读取 Cookie。
- 调用同花顺 provider。
- 读取 `raw_*`。
- 用 0 / 手填 / 随机 / 旧 payload / GPT 推断补教师先验。
- 越过 source preflight 发布 official signal。

---

## 21. 一句话总结

热点模型是以同花顺付费次日涨停概率为教师先验、以 source 标准事实和 available_at 时间线为硬约束的短窗口兑现研究模型：它负责候选可见性审计、阶段评分、release gate、open 5m 买点、观察、outcome、失败归因和 evolution；但教师概率只能来自 `source.ths_paid_limit_up_probability_v1`，official 必须先过 `/source/release/preflight`，缺概率、缺时间线或 source 阻断时必须保留缺口，不得补 0、不 mock、不绕过 source-data-service。
