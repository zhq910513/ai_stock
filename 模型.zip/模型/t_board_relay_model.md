# T 字板追踪模型归类总结

## 1. 模型定位

`t-board-relay-service` 是模型四 `t_board_relay` 的独立 owner service。

它研究的是 T 字板之后的三日接力行为：

```text
Day1：识别 T 字板，即开盘涨停、盘中开板、收盘回封。
Day2：09:30 起每 5 分钟滚动观察，接近涨停后进入盘口确认。
Day2：只有“买盘主动扫掉卖盘”且成交金额有效，才触发接力机会提示。
Day2：理论触发后到收盘只要开板，直接判废。
Day3：开盘涨停则留下；尾盘仍未涨停则生成退出研究事件。
```

本服务只做研究、观察、回放和审计，不下单、不生成 official signal、不替代买点服务。

---

## 2. 当前版本

| 项目 | 当前值 |
|---|---|
| 模型代码 | `t_board_relay` |
| 模型版本 | `t_board_relay_v1` |
| 特征版本 | `t_board_relay_feature_v1` |
| 规则版本 | `t_board_relay_rule_v1` |
| 生产决策域 | `decision_t_relay` |
| 研究域 | `research_t_relay` |

---

## 3. 服务边界

### 3.1 允许做的事

- 接收 research-service 已组装好的模型 payload。
- 执行 Day1 / Day2 / Day3 状态机。
- 输出候选、触发、封板维护、Day3 去留、outcome、博弈假设。
- 在 repository attached 时 append-only 写入 `decision_t_relay.*` 和 `research_t_relay.*`。
- 给前端提供只读 `observation-board` 投影。
- 给 scheduler 提供 non-official live dispatch 入口。
- 给 data-inspector 提供巡检闭环证据。

### 3.2 禁止做的事

- 不下单。
- 不写交易事实。
- 不发布 official signal。
- 不反写前三模型。
- 不直接采集 provider。
- 不读取 `raw_*`。
- 不用 sample payload 代替真实 source。
- 不用 0、mock、空字符串或推断值补齐缺失事实。

---

## 4. 核心状态流

```text
DAY1_SCAN
-> DAY1_T_BOARD_DETECTED
-> DAY1_T_BOARD_QUALIFIED
-> DAY2_PRE_WATCH
-> DAY2_ROLLING_5M_NEAR_LIMIT_WATCH
-> DAY2_ROLLING_NEAR_LIMIT_TRIGGER
-> DAY2_THEORETICAL_ENTRY
-> DAY2_POST_ENTRY_SEAL_MONITOR
-> DAY2_SEALED_TO_CLOSE / DAY2_BOARD_OPEN_FAILED
-> DAY3_OPEN_LIMIT_HOLD / DAY3_TAIL_NO_LIMIT_EXIT
-> FINAL_OUTCOME
```

时间口径必须按正常开市交易日解释：

```text
Day1 = 首个通过 T 字板规则的交易日
Day2 = Day1 后的下一个正常开市交易日
Day3 = Day2 后的下一个正常开市交易日
```

不得把同日历史记录拼成 Day2 或 Day3。

---

## 5. Day1 规则

### 5.1 输入来源

Day1 不是全 A 高频盲扫。

正确链路是：

```text
THS 公开涨停池
-> source.limit_event_v1
-> scheduler 只读筛出 T 字板阶段候选
-> 候选级补齐 P0 source
-> research-service 组装 payload
-> t-board-relay-service day1/scan
```

### 5.2 Day1 判定

Day1 需要识别：

- 开盘涨停。
- 盘中开板。
- 收盘回封涨停。
- 不是一字板。
- 流通市值在 50 亿到 300 亿之间。
- source 事实完整。

### 5.3 Day1 结果

Day1 输出候选状态：

- `qualified`：进入普通用户观察台。
- `rejected`：规则拒绝，保留审计，不进普通用户观察台。
- `data_blocked`：数据缺失或阻断，保留缺口，不进普通用户观察台。

普通用户观察台只纳入：

```text
candidate_status=qualified
is_t_board=true
float_market_cap_pass=true
```

---

## 6. Day2 规则

### 6.1 滚动观察

Day2 在 `09:30-10:30` 每 5 分钟滚动观察。

只有先接近涨停，才进入盘口确认。

### 6.2 触发确认

触发语义已经修正为：

```text
买盘主动扫掉卖盘 = 有效接力确认
卖盘主动砸向买盘 = 风险 / 失效条件
```

内部字段口径：

| 内部枚举 | 业务含义 | 结果 |
|---|---|---|
| `ASK` | 买盘主动扫掉卖盘 | 可触发接力机会提示 |
| `BID` | 卖盘主动砸向买盘 | 不触发，作为风险 / 失效 |
| 缺方向或缺金额 | 盘口方向待确认 | `data_blocked` 或等待确认 |

触发必须同时满足：

```text
Day1 合格
09:30-10:30 五分钟滚动接近涨停
order_consumption_side=ASK
order_consumption_amount>0
```

历史遗留的 `triggered+BID` 记录，在 observation-board 中也要按停止观察投影。

### 6.3 触发后封板维护

Day2 理论触发后，到收盘前只要开板：

```text
直接判废
即使后续回封，也不改变生产动作
```

post-entry monitor 必须 append-only 留存封板维护记录，并推动观察台状态、风险结论和更新时间。

---

## 7. Day3 规则

Day3 只处理去留研究事件：

- `09:25-09:35`：判断是否开盘涨停。
- `14:40-14:55`：尾盘仍未涨停，则生成退出研究事件。

核心输出：

- 开盘涨停：`hold_open_limit`
- 尾盘未涨停：`exit_tail_no_limit`

---

## 8. Source 数据合同

### 8.1 P0 source

P0 缺失时不得 official，只能 `data_blocked` 或 research-only：

- `source.daily_bar_v1`
- `source.limit_price_v1`
- `source.limit_event_v1`
- `source.trade_status_v1`
- `source.realtime_quote_v1.float_market_cap`
- `source.minute_bar_v1`
- `source.trade_tick_v1`

### 8.2 P1 source

P1 缺失可运行，但必须降置信并写 gap：

- `source.market_moneyflow_intraday_v1`
- `source.board_intraday_snapshot_v1`
- `source.intraday_moneyflow_snapshot_v1`
- `source.seal_order_snapshot_v1`
- `source.order_cancel_snapshot_v1`

### 8.3 P2 source

P2 只作为辅助证据：

- `source.news_event_v1`
- `source.announcement_event_v1`
- `source.sentiment_event_v1`

---

## 9. 动态特征依赖

模型四强依赖动态特征 bundle：

```text
t_board_relay_intraday_bundle_v1
```

当前仓库已有动态特征相关基线表：

- `decision.dynamic_feature_run`
- `decision.dynamic_feature_snapshot`
- `decision.dynamic_feature_latest`

但尚无独立 `dynamic-feature-service` 源码目录。

因此第一版只能接收：

- `dynamic_feature_run_id`
- `dynamic_feature_bundle`

缺失时必须保留：

```text
source_gap:dynamic_feature_bundle_missing
```

不得用 0、空字符串或推断值补齐。

---

## 10. 观察台 observation-board

### 10.1 定位

`GET /t-board-relay/observation-board` 是模型四给前端消费的只读投影。

它不是事实写入表，不触发 scheduler，不调用 provider，不生成 official signal。

### 10.2 纳入规则

只展示 Day1 合格对象：

```text
candidate_status=qualified
is_t_board=true
float_market_cap_pass=true
```

Day1 未通过、拒绝或数据阻断对象不进入普通用户主列表，但仍留在 Day1 repository 审计表。

### 10.3 查询排序规则

观察台必须：

1. 先读取 Day1 合格对象。
2. 在 owner 内部构建最多 500 条评分窗口。
3. 按 `model_score` 降序。
4. 无分对象后置。
5. 更新时间倒序。
6. 最后再按 `limit` 截断。

不得先取最新 Day1 前 N 行再过滤，否则 rejected 行会挤掉真实合格对象。

### 10.4 普通用户前端主列表字段

前端主列表只展示：

```text
股票 / 模型分 / Day1 / Day2 / 监测时间 / 当前判断 / 接力强度 / 关键依据 / 风险结论 / 更新
```

不展示：

- `current_stage`
- `day3_trade_date`
- `next_observation`
- `data_notice`
- `data_gap_labels`
- `source_gap:*`
- 审计大字段
- `ASK` / `BID`
- 无业务含义免责声明

### 10.5 文案规则

内部枚举必须翻译成普通用户能理解的中文：

| 内部事实 | 用户文案 |
|---|---|
| `ASK` | 买盘主动扫掉卖盘 |
| `BID` | 卖盘主动砸向买盘 |
| 缺方向 | 盘口方向待确认 |

`risk_tip` 必须来自真实风险事实，例如：

- 盘口方向风险。
- 成交强度不足。
- 封板维护失败。
- Day3 去留风险。
- 数据事实缺口。

不得输出“仅作观察、不自动下单”这类无业务含义提示。

---

## 11. 观察台时间口径

时间字段分三层，不能混用。

### 11.1 真实阶段事实时间

这些字段指向最新真实抓取 / 阶段事实时间：

- `latest_data_fetch_at`
- `last_data_captured_at`
- `updated_at`
- `display_update_at`
- `latest_snapshot_time`

优先取阶段记录中的：

- `as_of_time`
- `captured_at`
- `available_at`
- `as_of_time_utc`

没有业务时间时，才退回：

- `updated_at`
- `created_at`

### 11.2 5 分钟投影快照时间

```text
latest_projection_snapshot_at
```

只表示最近一次 5 分钟观察投影快照生成时间，用于 append-only 审计、恢复和排查调度留痕。

不得把它解释成真实抓取时间。

### 11.3 30 分钟模型结果时间

```text
last_model_output_at
model_evaluated_at
```

表示最近一次 30 分钟模型结果产出时间。

它可以更新模型判断、模型分和风险结论，但不得冒充真实抓取 / 阶段事实时间。

### 11.4 前端“更新”列

必须同时展示：

```text
最后一次模型产出时间
最新真实抓取 / 阶段事实时间
```

`latest_projection_snapshot_at` 只给审计，不作为前端真实更新时间。

---

## 12. 模型分

观察台同步输出：

- `model_score`
- `model_score_label`
- `score_state`
- `model_score_version=t_board_relay_observation_score_v1`

模型分由 owner 基于以下事实综合计算：

- Day1 封单 / 分歧吸收。
- Day2 五分钟滚动接近涨停。
- ASK 扫卖盘确认。
- BID 主动砸盘风险。
- 触发后封板维护。
- Day3 去留。
- outcome。
- 数据缺口事实。

关键事实缺失时：

```text
model_score=NULL
score_state=data_wait
```

不得补 0，也不得由前端推断。

---

## 13. 快照与持续监测

### 13.1 5 分钟观察投影快照

任务：

```text
t_relay.observation.monitor.snapshot_5m
POST /t-board-relay/observation-monitor/snapshot
```

语义：

- 每 5 分钟只读当前 observation-board。
- append-only 写入 `decision_t_relay.t_board_observation_monitor_snapshot_v1`。
- 用于观察投影留痕、恢复和审计。
- 不反写 Day2 / Day3 / outcome 阶段事实。
- 不补齐盘口或交易事实。

### 13.2 30 分钟模型结果快照

任务：

```text
t_relay.live_result.compute_30m
POST /t-board-relay/observation-monitor/snapshot
```

语义：

- 每 30 分钟产出模型结果版本。
- 写入 `last_model_output_at/model_evaluated_at`。
- 可更新模型分、模型判断和风险结论。
- 不得冒充真实抓取时间。

### 13.3 post-entry 封板维护

任务：

```text
t_relay.day2.post_entry.monitor
POST /t-board-relay/post-entry/monitor
```

语义：

- Day2 触发后，每 5 分钟跟踪封板。
- 触发后开板必须投影为停止观察。
- 保留原始监测记录。
- 更新观察台状态、风险结论和监测时间。

---

## 14. API 入口

### 14.1 健康检查

```text
GET /health
GET /healthz
GET /readyz
GET /t-board-relay/healthz
GET /t-board-relay/readyz
```

### 14.2 阶段接口

```text
POST /t-board-relay/day1/scan
GET  /t-board-relay/day1/candidates
GET  /t-board-relay/day1/candidates/{day1_candidate_id}

POST /t-board-relay/day2/watch
POST /t-board-relay/day2/trigger-check
GET  /t-board-relay/day2/triggers
GET  /t-board-relay/day2/triggers/{entry_trigger_id}

POST /t-board-relay/post-entry/monitor
GET  /t-board-relay/post-entry/status

POST /t-board-relay/day3/exit-check
GET  /t-board-relay/day3/decisions

POST /t-board-relay/outcomes/build
GET  /t-board-relay/outcomes

GET  /t-board-relay/game-hypotheses

GET  /t-board-relay/observation-board
POST /t-board-relay/observation-monitor/snapshot
GET  /t-board-relay/observation-monitor/snapshots

GET  /t-board-relay/repository/status
```

### 14.3 统一响应

```json
{
  "model_name": "t_board_relay",
  "model_version": "t_board_relay_v1",
  "structured_output": {},
  "jarvis_payload": {},
  "contract_gaps": []
}
```

Jarvis payload 只读，且必须明确：

```text
can_place_order=false
```

---

## 15. 落库表

repository attached 时，POST 阶段接口 append-only 写入：

- `decision_t_relay.t_board_day1_candidate_v1`
- `decision_t_relay.t_board_day2_watch_snapshot_v1`
- `decision_t_relay.t_board_day2_entry_trigger_v1`
- `decision_t_relay.t_board_day2_market_context_v1`
- `decision_t_relay.t_board_post_entry_monitor_v1`
- `decision_t_relay.t_board_day3_exit_decision_v1`
- `decision_t_relay.t_board_outcome_label_v1`
- `decision_t_relay.t_board_game_hypothesis_snapshot_v1`
- `decision_t_relay.t_board_observation_monitor_snapshot_v1`
- `research_t_relay.t_board_research_sample_v1`

所有表都是 append-only 审计事实：

- 每次 POST 写入新阶段记录。
- 保留原始 request payload。
- 保留 result payload。
- 保留模型版本、特征版本、run_id 和缺口码。
- 不覆盖历史坏版本。

---

## 16. 调度

模型四所有 scheduler 任务都是 non-official：

| task_code | endpoint |
|---|---|
| `t_relay.day1.scan.close` | `POST /t-board-relay/day1/scan` |
| `t_relay.day2.watch.rolling_5m` | `POST /t-board-relay/day2/watch` |
| `t_relay.day2.trigger.rolling_5m` | `POST /t-board-relay/day2/trigger-check` |
| `t_relay.day2.post_entry.monitor` | `POST /t-board-relay/post-entry/monitor` |
| `t_relay.day3.exit.open` | `POST /t-board-relay/day3/exit-check` |
| `t_relay.day3.exit.tail` | `POST /t-board-relay/day3/exit-check` |
| `t_relay.observation.monitor.snapshot_5m` | `POST /t-board-relay/observation-monitor/snapshot` |
| `t_relay.outcome.build` | `POST /t-board-relay/outcomes/build` |

scheduler 可以调度和 live dispatch owner service，但不得把模型四输出改写为：

- official signal
- 交易指令
- 买点版本
- 前三模型事实

---

## 17. 缺口码原则

常见缺口码包括：

- `source_gap:instrument_identity`
- `source_gap:daily_bar_missing`
- `source_gap:limit_price_missing`
- `source_gap:float_market_cap_missing`
- `source_gap:limit_event_missing`
- `source_gap:close_on_limit_flag_missing`
- `source_gap:one_word_limit_flag_missing`
- `source_gap:seal_order_snapshot_missing`
- `source_gap:minute_bar_or_realtime_quote_missing`
- `source_gap:dynamic_feature_bundle_missing`
- `source_gap:order_book_snapshot_missing`
- `source_gap:trade_tick_missing`
- `source_gap:near_limit_order_absorption_missing`
- `source_gap:post_entry_board_monitor_missing`
- `source_gap:day3_open_price_missing`
- `source_gap:day3_tail_price_missing`

缺口必须保留，不得补 0、空字符串、mock 或 GPT 推断。

普通用户前端不暴露 `source_gap:*`，只展示中文业务提示。

---

## 18. 当前闭环状态

当前模型四已经具备：

- 独立 owner service。
- Day1 / Day2 / Day3 状态机。
- 版本化阈值。
- 缺口码。
- 理论买入研究事件。
- 买入后封板维护硬规则。
- Day3 去留动作。
- outcome。
- 博弈假设输出。
- Postgres append-only repository。
- scheduler non-official live dispatch。
- data-inspector 巡检域。
- 前端只读 observation-board 投影。

仍未落地：

- 独立 `dynamic-feature-service` 源码。

因此动态特征缺口不阻断当前 Day1 / Day2 source、调度、repository 和巡检闭环，但必须保留缺口码。

---

## 19. 已冻结口径

### 19.1 Day1 合格对象观察台投影

冻结点：

- observation-board 只读读取 Day1 合格对象。
- 默认 `limit` 不得丢失已合格对象。
- rejected / data_blocked 不进入普通用户观察台。
- 文案中文化。
- 不暴露 `source_gap:*`。

### 19.2 owner repository / frontend-readonly 链路

冻结点：

- owner 健康契约。
- Day1 / Day2 / Day3 状态机。
- 正常开市交易日口径。
- append-only repository。
- observation-board 普通用户投影。
- scheduler non-official live dispatch。
- data-inspector 巡检域。
- 前端只读展示边界。

### 19.3 5 分钟观察快照留存

冻结点：

- snapshot 只读 observation-board。
- 每 5 分钟 append-only 写入快照表。
- 快照不替代 Day2 / Day3 / outcome 阶段事实。
- 快照不补盘口或交易事实。
- 快照时间不得伪装成真实抓取时间。

### 19.4 Day2 post-entry 开板失败投影

冻结点：

- Day2 有效触发后，post-entry monitor 具有最新事实优先级。
- 触发后只要开板，观察台必须显示停止观察。
- 风险结论必须来自封板维护失败、盘口方向、成交强度、Day3 去留或事实缺口。
- 不得恢复为“可买入观察”。

---

## 20. 一句话总结

T 字板追踪模型不是买点服务，而是一个以真实 source 和 append-only 阶段事实为基础的 T 字板三交易日接力研究模型：Day1 只筛合格 T 字板，Day2 只在买盘主动扫掉卖盘时触发观察，触发后开板即判废，Day3 根据开盘与尾盘涨停情况决定去留；所有结果只读投影给观察台，缺事实保留缺口，不补 0、不 mock、不发布 official signal。
